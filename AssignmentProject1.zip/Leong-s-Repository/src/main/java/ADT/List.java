package ADT;

//@author Yung Ka Leong 24SMR06234

import java.io.Serializable;

public class List<T> implements ListInterface<T>{
    private static final int DEFAULT_LENGTH = 5;
    
    private T[] array;
    private int numberOfEntries;
    
    public List(){
        this(DEFAULT_LENGTH);
    }
    public List(int givenLength){
        array = (T[]) new Object[givenLength];
        numberOfEntries = 0;
    }
    
    @Override
    public boolean add(T newEntry){
        if(isArrayFull()){
            doubleArray();
        }
        
        array[numberOfEntries] = newEntry;
        numberOfEntries++;
        
        return true;
    }
    
    @Override
    public boolean add(int newPosition, T newEntry){
        if( (newPosition < 1) || (newPosition > numberOfEntries + 1) ){
            return false;
        }
        else if(isArrayFull()){
            doubleArray();
        }
        
        shiftRight(newPosition);
        array[newPosition - 1] = newEntry;
        numberOfEntries++;
        
        return true;
    }
    
    @Override
    public T remove(int givenPosition){
        if( (givenPosition < 1) || (givenPosition > numberOfEntries) ){
            return null;
        }
        
        T result = array[givenPosition - 1];
        if(givenPosition < numberOfEntries){
            shiftLeft(givenPosition);
        }
        numberOfEntries--;
        
        return result;
    }
    
    @Override
    public boolean replace(int givenPosition, T newEntry){
        if( (givenPosition < 1) || (givenPosition > numberOfEntries) ){
            return false;
        }
        
        array[givenPosition - 1] = newEntry;
        
        return true;
    }
    
    @Override
    public T getEntry(int givenPosition){
        if( (givenPosition < 1) || (givenPosition > numberOfEntries) ){
            return null;
        }
        
        return array[givenPosition - 1];
    }
    
    @Override
    public boolean contains(T anEntry){
        if(isEmpty()){
            return false;
        }
        
        for(int i = 0; i < numberOfEntries; i++){
            if(anEntry.equals(array[i])){
                return true;
            }
        }
        
        return false;
    }
    
    @Override
    public int getNumberOfEntries(){
        return numberOfEntries;
    }
    
    @Override
    public boolean isEmpty(){
        return (numberOfEntries == 0);
    }
    
    @Override
    public void clear(){
        array = (T[]) new Object[DEFAULT_LENGTH];
        numberOfEntries = 0;
    }
    
    private boolean isArrayFull(){
        return (numberOfEntries == array.length);
    }
    
    private void doubleArray(){
        T[] oldArray = array;
        array = (T[]) new Object[oldArray.length * 2];
        for(int i = 0; i < oldArray.length; i++){
            array[i] = oldArray[i];
        }
    }
    
    private void shiftRight(int newPosition){
        int newIndex = newPosition - 1;
        int lastIndex = numberOfEntries - 1;
        
        for(int i = lastIndex; i >= newIndex; i--){
            array[i + 1] = array[i];
        }
    }
    
    private void shiftLeft(int givenPosition){
        int removedIndex = givenPosition - 1;
        int lastIndex = numberOfEntries - 1;
        
        for(int i = removedIndex; i < lastIndex; i++){
            array[i] = array[i + 1];
        }
    }
}
