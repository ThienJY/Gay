package ADT;

//@author Yung Ka Leong 24SMR06234

public class LinkedQueue<T> implements QueueInterface<T> {
    private Node firstNode;
    private Node lastNode;
    private int numberOfEntry;
    
    public LinkedQueue(){
        clear();
    }
    
    @Override
    public void enqueue(T newEntry){
        Node newNode = new Node(newEntry);
        
        if(isEmpty()){
            firstNode = newNode;
            lastNode = newNode;
        }
        else{
            lastNode.next = newNode;
            lastNode = newNode;
        }
        
        numberOfEntry++;
    }
    
    @Override
    public T dequeue(){
        T result;
        
        if(isEmpty()){
            result = null;
        }
        else{
            result = firstNode.data;
            firstNode = firstNode.next;
        }
        
        return result;
    }
    
    @Override
    public T getFront(){
        if(isEmpty()){
            return null;
        }
        else{
            return firstNode.data;
        }
    }
    
    @Override
    public T[] getArray(){
        T[] array = (T[]) new Object[numberOfEntry];
        Node currentNode = firstNode;
        
        if(isEmpty()){
            array = null;
        }
        else{
            for(int i = 0; i < numberOfEntry; i++){
                array[i] = currentNode.data;
                currentNode = currentNode.next;
            }
        }
        
        return array;
    }
    
    @Override
    public boolean isEmpty(){
        return (numberOfEntry == 0);
    }
    
    @Override
    public final void clear(){
        firstNode = null;
        lastNode = null;
        numberOfEntry = 0;
    }
    
    private class Node{
        private T data;
        private Node next;
        
        private Node(T data){
            this.data = data;
            next = null;
        }
    }
    
}
