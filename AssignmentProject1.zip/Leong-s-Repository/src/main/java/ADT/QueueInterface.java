package ADT;

//@author Yung Ka Leong 24SMR06234

public interface QueueInterface<T> {
    
    public void enqueue(T newEntry);
    
    public T dequeue();
    
    public T getFront();
    
    public T[] getArray();
    
    public boolean isEmpty();
    
    public void clear();
}
