package ADT;

//@author Yung Ka Leong 24SMR06234

import java.io.Serializable;

public interface ListInterface<T> extends Serializable{
    
    public boolean add(T newEntry);
    
    public boolean add(int newPosition, T newEntry);
    
    public T remove(int givenPosition);
    
    public boolean replace(int givenPosition, T newEntry);
    
    public T getEntry(int givenPosition);
    
    public boolean contains(T anEntry);
    
    public int getNumberOfEntries();
    
    public boolean isEmpty();
    
    public void clear();
}
